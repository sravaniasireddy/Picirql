package utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CommonMethods {
	
	public String dateFormatting(String parseDate) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("MMM dd, yyyy");
		Date date = sdf.parse(parseDate);
		return sdf1.format(date);
	}
	
	public String todayDate() throws ParseException{
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	public Date calendarOperations(Date date, int days){
	        Calendar cal = Calendar.getInstance();
	        cal.setTime(date);
	        cal.add(Calendar.DATE, days); 
	        return cal.getTime();
	}
	
	public  DateFormat dateFormat = new SimpleDateFormat("MM/dd/YYYY");

	public  String currentDate(){

		Date date = new Date();
        return dateFormat.format(date).toString();
	}
	
	public  String futureDateselection(){
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, 15);
        return dateFormat.format(c.getTime());
	}
	
	public  String PastDateselection(){
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE, -7);
        return dateFormat.format(c.getTime());
	}
	
	public  String monthName(){
		Calendar c = Calendar.getInstance();
		return new SimpleDateFormat("MMM").format(c.getTime());
	}
	
	public String dateFormat(String value) throws ParseException{
		SimpleDateFormat sdfSource = new SimpleDateFormat("MM/dd/yyyy");
	    Date date = sdfSource.parse(value);
	    SimpleDateFormat sdfDestination = new SimpleDateFormat("MMM,dd yyyy");
	    return sdfDestination.format(date);
	}
}
