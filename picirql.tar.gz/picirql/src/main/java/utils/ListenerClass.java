package utils;

import java.util.logging.Logger;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import beehyv.picirql.ContactPageTest;

public class ListenerClass extends TestListenerAdapter {
	private final Logger LOGGER = Logger.getLogger(ContactPageTest.class.getName());
	@Override
	public void onTestStart(ITestResult tr) {
		LOGGER.info(tr.getTestClass() +": Test Started....");
	}

	@Override
	public void onTestSuccess(ITestResult tr) {

		LOGGER.info("Test '" + tr.getName() + "' PASSED");
	}

	@Override
	public void onTestFailure(ITestResult tr) {

		LOGGER.info("Test '" + tr.getName() + "' FAILED");
	}

	@Override
	public void onTestSkipped(ITestResult tr) {
		LOGGER.info("Test '" + tr.getName() + "' SKIPPED");
	}


}
