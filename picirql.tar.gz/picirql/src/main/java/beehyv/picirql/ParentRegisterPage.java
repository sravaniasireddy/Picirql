package beehyv.picirql;

import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ParentRegisterPage extends LoginPage{
	private final Logger LOGGER = Logger.getLogger(ParentRegisterPage.class.getName());
	
	By firstName = By.id("first_name");
	By lastName = By.id("last_name");
	By registerButton = By.id("register");
	By errorMessages = By.xpath(".//*[@id='error-messages']/div/p");
	
	public void createAccount(String fname, String lname, String email, String pswd){
		try{
			driver.findElement(firstName).clear();
			driver.findElement(firstName).sendKeys(fname);
			driver.findElement(lastName).clear();
			driver.findElement(lastName).sendKeys(lname);
			driver.findElement(userEmail).clear();
			driver.findElement(userEmail).sendKeys(email);
			driver.findElement(userPassword).clear();
			driver.findElement(userPassword).sendKeys(pswd);
			driver.findElement(registerButton).click();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean errorMessage(String msg){
		boolean status=false;
		try{
			waitUntilErrorMessages();
			String[] msgs = driver.findElement(errorMessages).getText().split("/n");
			for(String text:msgs){
				LOGGER.info(text);
				if(text.contains(msg)){
					status=true;
					break;
				}
			}
			return status;
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
	}
	
	public void waitUntilErrorMessages(){
		WebElement myDynamicElement1 = (new WebDriverWait(driver, 200))
	    		  .until(ExpectedConditions.visibilityOfElementLocated(errorMessages));
	}
	
	
}
