package beehyv.picirql;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class HomePage extends LandingPage{
	private final Logger LOGGER = Logger.getLogger(HomePage.class.getName());
	By videoTabHeader = By.xpath(".//*[@id='video-tab']/div/div[1]/h1");
	By videoTabs = By.xpath(".//*[@id='video-tab']/div/div[2]/ul/li/a");
	By LeaderboardHeader = By.xpath(".//*[@id='leaderboard-tab']/div/div[1]/h1");
	By LeaderboardTabs = By.xpath(".//*[@id='leaderboard-tab']/div/div[2]/ul/li/a");
	
	public String videoTabHeaderText(){
		String text=null;
		try{
			if(driver.findElement(videoTabHeader).isDisplayed()){
				moveToWebElement(driver.findElement(videoTabHeader));
				text=driver.findElement(videoTabHeader).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
	}
	public String LeaderboardHeaderText(){
		String text=null;
		try{
			if(driver.findElement(LeaderboardHeader).isDisplayed()){
				text=driver.findElement(LeaderboardHeader).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return text;
	}
	public void videoTabSelection(String tabName){
		try{
			List<WebElement> tabs = driver.findElements(videoTabs);
			 for(WebElement tab:tabs){
				 moveToWebElement(tab);
				 driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
				 if(tab.getText().equals(tabName)){
					 tab.click();
					 driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
					 break;
				 }
			 }
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public boolean videoTabStatus(String tabName){
		boolean status=false;
		try{
			List<WebElement> tabs = driver.findElements(videoTabs);
			 for(WebElement tab:tabs){
				 moveToWebElement(tab);
				 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
				 if(tab.getText().equals(tabName)){
					 status = tab.isEnabled();
					 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
					 break;
				 }
			 }
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
	}
	
	public void LeaderboardTabSelection(String tabName){
		try{
			List<WebElement> tabs = driver.findElements(LeaderboardTabs);
			 for(WebElement tab:tabs){
				 moveToWebElement(tab);
				 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
				 if(tab.getText().equals(tabName)){
					 tab.click();
					 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
					 break;
				 }
			 }
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean LeaderboardTabStatus(String tabName){
		boolean status=false;
		try{
			List<WebElement> tabs = driver.findElements(LeaderboardTabs);
			 for(WebElement tab:tabs){
				 moveToWebElement(tab);
				 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
				 if(tab.getText().equals(tabName)){
					 status = tab.isEnabled();
					 LOGGER.info(""+status);
					 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
					 break;
				 }
			 }
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
	}
}
