package beehyv.picirql;

import java.util.logging.Logger;

import org.openqa.selenium.By;

public class ContactPage extends LandingPage{
	private final Logger LOGGER = Logger.getLogger(ContactPage.class.getName());
	By confirmationMessage = By.id("confirm-message");
	By fullName = By.id("fullname");
	By emailAddress = By.id("email");
	By messageContent = By.id("message");
	By submitButton = By.id("submit_button");
	By dataMessage = By.id("data-message");
	
	public void sendingMail(String name,String email, String message){
		try{
			driver.findElement(fullName).sendKeys(name);
			driver.findElement(emailAddress).sendKeys(email);
			driver.findElement(messageContent).sendKeys(message);
			driver.findElement(submitButton).click();
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String formResponse(){
		String response = null;
		try{
			if(driver.findElement(dataMessage).isDisplayed()){
				response = driver.findElement(dataMessage).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}
}
