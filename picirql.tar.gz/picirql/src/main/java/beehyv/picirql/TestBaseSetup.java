package beehyv.picirql;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

public class TestBaseSetup {

	public static WebDriver driver;
	private final Logger log = Logger.getLogger(TestBaseSetup.class.getName());
	public FileInputStream  data = null;
	public Properties q = null;
	
	@BeforeClass
	public void setDriver() throws IOException{
		data = new FileInputStream(System.getProperty("user.dir")+"/src/test-data/testData.properties");
		q=new Properties();
		q.load(data);
		if (q.getProperty("setup.browser").equalsIgnoreCase("Firefox")) {
//			System.setProperty("webdriver.gecko.driver", "/home/beehyv/geckodriver");
			System.setProperty("webdriver.firefox.marionette","/home/beehyv/geckodriver.exe");
			driver = new FirefoxDriver();
		} else if (q.getProperty("setup.browser").equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "/home/beehyv/Downloads/chromedriver");
			driver = new ChromeDriver();
		} /*else if (p.getProperty("browser.type").equalsIgnoreCase("IE")) {
			System.setProperty("webdriver.chrome.driver", "/home/beehyv/Downloads/chromedriver");
			driver = new InternetExplorerDriver();
		}*/
		log.info("Open Driver");
		driver.manage().window().maximize();
		driver.get(q.getProperty("setup.URL"));
	}
	
	@AfterClass
	public void CloseDriver(){
		driver.quit();
		log.info("Browser is successfully terminated");
	}
	
	public void screenShot(String name){
		try{
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		// Now you can do whatever you need to do with it, for example copy somewhere
		FileUtils.copyFile(scrFile, new File(name));
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
	}
	
	public String currentURL(){
		String URL = null;
		try{
				URL = driver.getCurrentUrl();
			}
			catch(Exception e){
				e.printStackTrace();
				
			}
		return URL;
	}
	
	public void moveToWebElement(WebElement element){
		try{
			Actions ac = new Actions(driver);
			ac.moveToElement(element).build().perform();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void browserBack(String url){
		try{
			driver.get(url);
			driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public void browserRefresh(){
		try{
			driver.navigate().refresh();
			driver.manage().timeouts().implicitlyWait(200,TimeUnit.SECONDS);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String pageTitle(){
		String title=null;
		try{
			 if(driver.getTitle().equalsIgnoreCase("null")){
				 log.info(driver.getTitle());
			 }
			 else{
				 title=driver.getTitle();
			 }
		}catch(Exception e){
			e.printStackTrace();
		}
		return title;
	}
}
