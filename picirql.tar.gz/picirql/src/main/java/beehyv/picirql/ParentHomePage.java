package beehyv.picirql;

import java.util.List;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ParentHomePage extends StudentHomePage {
	private final Logger LOGGER = Logger.getLogger(ParentHomePage.class.getName());
	By logoutButton = By.xpath(".//*[@id='site-menu-collapse']/ul[2]/li[2]/a");
	By navBar = By.xpath("html/body/div[2]/nav/div/ul/li");
	By navBarOptions = By.xpath("html/body/div[2]/nav/div/ul/li/a");
	By chidrenList = By.className("aside-block children-listing left-block");
	By chidrenListHeader = By.tagName("h3");
	By childrenBlockList = By.xpath(".//*[@id='aside-block-children-list']/div");
	By childrenBlockListNames = By.xpath(".//*[@id='aside-block-children-list']/div/div[2]/h4/a");
	By addChildLink = By.xpath(".//*[@id='page-update']/div[2]/div[1]/div[1]/div[1]/a[1]");
	By addChildrenForm = By.id("billing-registration-form");
	By addChildFormHeader = By.xpath(".//*[@id='billing-registration-form']/h2");
	By childSelected = By.id("child-selection");
	
	
	public void navBarSelection(String Name){
		try{
			List<WebElement>  options = driver.findElements(navBarOptions);
			for(WebElement option:options){
					if(option.getText().equals(Name)){
						moveToWebElement(option);
						option.click();
						break;
					}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String selectedTab(){
		String tab=null;
		try{
			List<WebElement>  options = driver.findElements(navBar);
			for(WebElement option:options){
				if(option.getAttribute("class").contains("active")){
					tab=option.findElement(levNavBarOptionValue).getText();
					break;
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return tab;
	}
	
	public String childrenBlockHeader(){
		String header=null;
		try{
			header = driver.findElement(chidrenListHeader).getText();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	
	public void addChildPage(){
		try{
			if(driver.findElement(addChildLink).isDisplayed()){
				driver.findElement(addChildLink).click();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void waitUntilAddChildPage(){
		WebElement myDynamicElement1 = (new WebDriverWait(driver, 200))
	    		  .until(ExpectedConditions.visibilityOfElementLocated(addChildrenForm));
	}
	
	public String newChildFormHeader(){
		String header=null;
		try{
			if(driver.findElement(addChildFormHeader).isDisplayed()){
				header = driver.findElement(addChildFormHeader).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	
	public void waitUntilChildDetailsPage(){
		WebElement myDynamicElement1 = (new WebDriverWait(driver, 200))
	    		  .until(ExpectedConditions.visibilityOfElementLocated(childSelected));
	}
	public void waitUntilchildrenBlockList(){
		WebElement myDynamicElement1 = (new WebDriverWait(driver, 200))
	    		  .until(ExpectedConditions.visibilityOfElementLocated(childrenBlockListNames));
	}
	public void ChildrenDeatils(){
		try{
			List<WebElement>  options = driver.findElements(childrenBlockListNames);
			LOGGER.info(""+options.size());
			for(WebElement option:options){
				String name= option.getText();
				option.click();
				waitUntilChildDetailsPage();
				if(driver.findElement(childSelected).getText().equals(name)){
					home();
					waitUntilchildrenBlockList();
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
}
