package beehyv.picirql;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class LandingPage extends TestBaseSetup{
	private final Logger LOGGER = Logger.getLogger(LandingPage.class.getName());
	By logoImage =By.xpath(".//*[@id='site-header']/div/div[1]/div/a/img");
	By headerLinks = By.cssSelector(".nav.navbar-nav.navbar-left>li>a");
	By headerTextOne = By.tagName("h1");
	By headerTextTwo = By.tagName("h4");
	By footerLinks = By.cssSelector("#footer-menu>li>a");
	By homePageContent = By.xpath(".//*[@id='home-header']/div[2]/div");
	
	By officeAddress = By.xpath(".//*[@id='text-9']/div/p[2]");
	By footerSocialSites = By.xpath(".//*[@id='site-footer']/div/div[1]/div[4]/a/i");
	By loginLink = By.linkText("LOGIN");
	By registerLink = By.linkText("REGISTER");
	By startLearningNow = By.xpath(".//*[@id='post-39']/div/div[7]/div/div/div[2]/a");
	
	
	public boolean startLearningNowStatus(){
		boolean status = false;
		try{
			moveToWebElement(driver.findElement(startLearningNow));
			status=driver.findElement(startLearningNow).isDisplayed()&&driver.findElement(startLearningNow).isEnabled();
			
		}catch(Exception e){
    		e.printStackTrace();
    	}
		return status;
	}
	
	public void waitUntilHomePageContent(){
		WebElement myDynamicElement1 = (new WebDriverWait(driver, 200))
	    		  .until(ExpectedConditions.visibilityOfElementLocated(homePageContent));
	}
	
	public boolean appLogo(){
		boolean status = false;
		try{
			
			status=driver.findElement(logoImage).isDisplayed();
			
		}catch(Exception e){
    		e.printStackTrace();
    	}
		return status;
	}
	
	
	public void home(){
		try{
			
			if(driver.findElement(logoImage).isDisplayed()){
				driver.findElement(logoImage).click();
			}
			
		}catch(Exception e){
    		e.printStackTrace();
    	}
	}
	public void headersText(){
		try{
			 List<WebElement> headers = driver.findElements(headerLinks);
			 for(WebElement header:headers){
				 LOGGER.info(header.getText());
			 }
		}catch(Exception e){
    		e.printStackTrace();
    	}
	}
	
	public void headersSelection(String headerName){
		try{
			 List<WebElement> headers = driver.findElements(headerLinks);
			 for(WebElement header:headers){
				 moveToWebElement(header);
				 if(header.getText().equals(headerName)){
					 header.click();
					 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
					 break;
				 }
			 }
		}catch(Exception e){
    		e.printStackTrace();
    	}
	}
	
	public void footersSelection(String footerName){
		try{
			List<WebElement> footers = driver.findElements(footerLinks);
			 for(WebElement footer:footers){
				 moveToWebElement(footer);
				 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
				 if(footer.getText().equals(footerName)){
					 footer.click();
					 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
					 break;
				 }
			 }
		}catch(Exception e){
    		e.printStackTrace();
    	}
	}
	
	public void loginPage(){
		try{
			if(driver.findElement(loginLink).isDisplayed()&&driver.findElement(loginLink).isEnabled()){
				driver.findElement(loginLink).click();
				 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void registerPage(){
		try{
			if(driver.findElement(registerLink).isDisplayed()&&driver.findElement(registerLink).isEnabled()){
				driver.findElement(registerLink).click();
				 driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String addressText(String value){
		String line = null;
		try{
			 if(driver.findElement(officeAddress).isDisplayed()){
				 moveToWebElement(driver.findElement(officeAddress));
				 line =  driver.findElement(officeAddress).getText();
				 String[] line1 = line.split("/n");
				 for(String text:line1){
					 LOGGER.info(text);
					 if(text.equals(value)){
						 line=text;
					 }
				 }
				 
			 }
			 return line;
		}catch(Exception e){
    		e.printStackTrace();
    		return line;
    	}
	}
	
	public void browserTerminate(){
		try{
			driver.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
}
