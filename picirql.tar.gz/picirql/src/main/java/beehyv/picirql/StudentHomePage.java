package beehyv.picirql;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class StudentHomePage extends LoginPage {
	private final Logger LOGGER = Logger.getLogger(StudentHomePage.class.getName());
	By logoutButton = By.xpath(".//*[@id='site-menu-collapse']/ul[2]/li[2]/a");
	By navBar = By.xpath("html/body/div[2]/nav/div/div/ul/li/a");
	By navBarOptions = By.xpath("html/body/div[2]/nav/div/div/ul/li");

	By profileHeader = By.xpath(".//*[@id='profile-info-left']/div/h3");
	By levNavBarOptions = By.xpath(".//*[@id='profile-info-left']/div[2]/ul/li");
	By levNavBarOptionValue = By.tagName("a");
	By pageName = By.xpath(".//*[@id='page-friends']/div[2]/div[2]/div[1]/div/h3");
	
	By evaluationPageHeader = By.id("evaluation-heading");
	By faqHeader = By.xpath(".//*[@id='page-faq']/div[2]/div[1]/div[2]/div[1]");

	By inviteFriendHeader = By.xpath(".//*[@id='page-edit']/div[2]/div[2]/div/div[1]/p");
	By friendEmail = By.id("invite-email");
	By inviteSubmit = By.id("invite-submit");
	By inviteError = By.className("invite-error-message");
	By editProfileHeader = By.xpath(".//*[@id='page-edit']/div[2]/div[2]/div/div[2]");
	By email = By.id("email");
	By password = By.id("password");
	By confirmPassword = By.id("confirmPass");
	By updateButton = By.id("update");
	
	
	By suggestFriend = By.id("suggested-friends");
	By suggestFriendHeader = By.xpath(".//*[@id='suggested-friends']/div/h3");
	By searchFriend = By.xpath(".//*[@id='aside-block-children-list-suggested-friends']/div[1]/form/input");
	By searchResultsHeader = By.xpath(".//*[@id='page-search-result']/div[2]/div[2]/div/div[1]/h3");
	By searchResulttext = By.xpath(".//*[@id='page-search-result']/div[2]/div[2]/div/div/div");
	By serachResults = By.xpath(".//*[@id='page-search-result']/div[2]/div[2]/div/div[2]/ul/li/div/div[2]/ul");
	By friendName = By.className("friend-name");
	By friendSchool = By.className("friend-school-name");
	By friendPoints = By.className("friend-current-points");
	By friendConnect = By.className("btn-search-friend-connect");
	
	public void searchFriend(String name){
		try{
			if(driver.findElement(searchFriend).isDisplayed()){
				driver.findElement(searchFriend).sendKeys(name,Keys.ENTER);
			}		
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	
	public String friendsList(String name){
		String text=null;
		try{
			if(driver.findElement(searchResultsHeader).getText().contains(name)){
				List<WebElement>  options = driver.findElements(serachResults);
				if(options.size()==0){
					text = driver.findElement(searchResulttext).getText(); 
				}
				else{
					for(WebElement option:options){
						LOGGER.info(option.findElement(friendName).getText());
						if(option.findElement(friendName).getText().contains(name)){
							text=option.findElement(friendName).getText();
						}
					}
				}
						
			}
		}catch(Exception e){
			
		}
		return text;
	}
	
	public void navBarSelection(String Name){
		try{
			List<WebElement>  options = driver.findElements(navBar);
			for(WebElement option:options){
					if(option.getText().equals(Name)){
						moveToWebElement(option);
						option.click();
						break;
					}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void profileOptionSelection(String Name){
		try{
			List<WebElement>  options = driver.findElements(levNavBarOptions);
			for(WebElement option:options){
					if(option.findElement(levNavBarOptionValue).getAttribute("title").equals(Name)){
						moveToWebElement(option);
						option.click();
						break;
					}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String selectedTab(){
		String tab=null;
		try{
			List<WebElement>  options = driver.findElements(navBarOptions);
			for(WebElement option:options){
				if(option.getAttribute("class").contains("active")){
					tab=option.findElement(levNavBarOptionValue).getText();
					break;
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return tab;
	}
	public String selectedPage(){
		String page=null;
		try{
			List<WebElement>  options = driver.findElements(levNavBarOptions);
			for(WebElement option:options){
				if(option.getAttribute("class").matches("profile-menu-item clearfix active")){
					page=option.findElement(levNavBarOptionValue).getAttribute("title");
					break;
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return page;
	}
	
	public String evaluationsHeader(){
		String header=null;
		try{
			if(driver.findElement(evaluationPageHeader).isDisplayed()){
				header=driver.findElement(evaluationPageHeader).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	
	public String faqHeader(){
		String header=null;
		try{
			if(driver.findElement(faqHeader).isDisplayed()){
				header=driver.findElement(faqHeader).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	
	public void inviteFriend(String value){
		try{
			if(driver.findElement(inviteFriendHeader).isDisplayed()){
				driver.findElement(friendEmail).sendKeys(value);
				driver.findElement(inviteSubmit).click();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String confirmationInviteFriend(){
		String msg=null;
		try{
			if(driver.findElement(inviteFriendHeader).isDisplayed()){
				msg=driver.findElement(inviteError).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return msg;
	}
}
