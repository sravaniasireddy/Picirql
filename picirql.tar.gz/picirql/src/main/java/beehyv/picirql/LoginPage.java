package beehyv.picirql;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LoginPage extends LandingPage{
	private final Logger LOGGER = Logger.getLogger(LoginPage.class.getName());
	By loginFormHeader = By.tagName("h2");
	By userTypeLabel = By.xpath(".//*[@id='registration-form']/div[1]/label");
	By userType = By.xpath(".//*[@id='prefix']");
	By userTypeOption = By.xpath(".//*[@id='prefix']/option");
	By userEmail = By.id("email");
	By userPassword = By.id("password");
	By loginButton = By.id("login");
	By forgotPassword = By.id("login-forgot-password");
	By errorMessage = By.xpath(".//*[@id='error-messages']/div");
	By registerText = By.id("parents-register-students");
	By registerLink = By.xpath(".//*[@id='goto-register']");
	
	public String formHeader(){
		String header = null;
		try{
			if(driver.findElement(loginFormHeader).isDisplayed()){
				header=driver.findElement(loginFormHeader).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	
	public String userTypeLabelText(){
		String header = null;
		try{
			if(driver.findElement(userTypeLabel).isDisplayed()){
				header=driver.findElement(userTypeLabel).getText();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return header;
	}
	public void userTypeSelection(String type){
		try{
			if(driver.findElement(userType).isDisplayed()){
				driver.findElement(userType).click();
				driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
				List<WebElement> options = driver.findElements(userTypeOption);
				for(WebElement option:options){
					if(option.getAttribute("value").equals(type)){
						option.click();
						break;
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void loginCase(String type,String email, String password){
		try{
			userTypeSelection(type);
			driver.findElement(userEmail).sendKeys(email);
			driver.findElement(userPassword).sendKeys(password);
			driver.findElement(loginButton).click();
			driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public boolean errorMessage(){
		boolean status = false;
		try{
			if(driver.findElement(errorMessage).isDisplayed()){
				status=true;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return status;
	}
	
	public void forgotPasswordLink(){
		try{
			if(driver.findElement(forgotPassword).isDisplayed()){
				driver.findElement(forgotPassword).click();
				driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void registerLink(){
		try{
			if(driver.findElement(registerLink).isDisplayed()){
				driver.findElement(registerLink).click();
				driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public String selectedUserType(){
		String type=null;
		try{
			if(driver.findElement(userType).isDisplayed()){
				type=driver.findElement(userTypeLabel).getAttribute("value");
				List<WebElement> options = driver.findElements(userTypeOption);
				for(WebElement option:options){
					if(option.getAttribute("value").equals("0")){
						type= option.getText();
						break;
					}else if(option.getAttribute("value").equals("1")){
						type= option.getText();
						break;
				}else if(option.getAttribute("value").equals("-1")){
					type= option.getText();
					break;
				}else{
					type= option.getText();
					break;
				}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return type;
	}
}
