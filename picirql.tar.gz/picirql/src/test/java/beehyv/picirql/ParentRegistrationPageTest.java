package beehyv.picirql;

import org.testng.annotations.Test;

import junit.framework.Assert;

public class ParentRegistrationPageTest extends ParentRegisterPage {
	@Test(priority=1)
	public void RegisterPage(){
		registerPage();
	}
	
	@Test(priority=2)
	public void accountCreation(){
		createAccount("","","","");
		Assert.assertEquals(true, errorMessage("First name is required"));
		Assert.assertEquals(true, errorMessage("Last name is required"));
		Assert.assertEquals(true, errorMessage("Email is required"));
		Assert.assertEquals(true, errorMessage("Password is required"));
	}
	@Test(priority=3)
	public void invalidFname(){
		createAccount("","lname","fl@gmail.com","test");
		Assert.assertEquals(true, errorMessage("First name is required"));
	}
	@Test(priority=4)
	public void invalidLname(){
		createAccount("fname","","fl@gmail.com","test");
		Assert.assertEquals(true, errorMessage("Last name is required"));
	}
	@Test(priority=5)
	public void invalidEmail(){
		createAccount("fname","lname","","test");
		Assert.assertEquals(true, errorMessage("Email is required"));
	}
	@Test(priority=6)
	public void invalidPswd(){
		createAccount("fname","lname","fl@gmail.com","");
		Assert.assertEquals(true, errorMessage("Please provide a password."));
	}
}
