package beehyv.picirql;

import org.testng.Assert;
import org.testng.annotations.*;
import utils.CommonMethods;

public class HomePageTest extends HomePage{
	
	@Test(priority=1)
	public void logoVerification(){
		//Assert.assertEquals(appLogo(), true);
		headersSelection(q.getProperty("header.one"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.home"));
	}
	
	@Test(priority=2)
	public void startLearningNowLink(){
		Assert.assertEquals(startLearningNowStatus(), true);
	}
	@Test(priority=3)
	public void approachHeader(){
		Assert.assertEquals(videoTabHeaderText(), q.getProperty("homepage.vediotabheader"));
	}
	@Test(priority=4)
	public void missonTab(){
		videoTabSelection(q.getProperty("homepage.vediotab1"));
		Assert.assertEquals(videoTabStatus(q.getProperty("homepage.vediotab1")), true);
	}
	@Test(priority=5)
	public void productTab(){
		videoTabSelection(q.getProperty("homepage.vediotab2"));
		Assert.assertEquals(videoTabStatus(q.getProperty("homepage.vediotab2")), true);
	}
	@Test(priority=6)
	public void philosophyTab(){
		videoTabSelection(q.getProperty("homepage.vediotab3"));
		Assert.assertEquals(videoTabStatus(q.getProperty("homepage.vediotab3")), true);
	}
	@Test(priority=7)
	public void leaderboardHeader(){
		Assert.assertEquals(LeaderboardHeaderText(), q.getProperty("homepage.leaderboardheader"));
	}
	@Test(priority=8)
	public void leaderboardTab1(){
		LeaderboardTabSelection(q.getProperty("homepage.leaderboardtab1"));
		Assert.assertEquals(LeaderboardTabStatus(q.getProperty("homepage.leaderboardtab1")), true);
	}
	@Test(priority=8)
	public void leaderboardTab2(){
		LeaderboardTabSelection(q.getProperty("homepage.leaderboardtab2"));
		Assert.assertEquals(LeaderboardTabStatus(q.getProperty("homepage.leaderboardtab2")), true);
	}
	@Test(priority=10)
	public void leaderboardTab3(){
		LeaderboardTabSelection(q.getProperty("homepage.leaderboardtab3"));
		Assert.assertEquals(LeaderboardTabStatus(q.getProperty("homepage.leaderboardtab3")), true);
	}
	@Test(priority=11)
	public void leaderboardTab4(){
		LeaderboardTabSelection(q.getProperty("homepage.leaderboardtab4"));
		Assert.assertEquals(LeaderboardTabStatus(q.getProperty("homepage.leaderboardtab4")), true);
	}
	@Test(priority=12)
	public void leaderboardTab5(){
		LeaderboardTabSelection(q.getProperty("homepage.leaderboardtab5"));
		Assert.assertEquals(LeaderboardTabStatus(q.getProperty("homepage.leaderboardtab5")), true);
	}
	@Test(priority=13)
	public void leaderboardTab6(){
		LeaderboardTabSelection(q.getProperty("homepage.leaderboardtab6"));
		Assert.assertEquals(LeaderboardTabStatus(q.getProperty("homepage.leaderboardtab6")), true);
	}
	@Test(priority=14)
	public void leaderboardTab7(){
		LeaderboardTabSelection(q.getProperty("homepage.leaderboardtab7"));
		Assert.assertEquals(LeaderboardTabStatus(q.getProperty("homepage.leaderboardtab7")), true);
	}
}
