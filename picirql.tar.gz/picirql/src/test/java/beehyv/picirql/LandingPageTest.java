package beehyv.picirql;

import org.testng.Assert;
import org.testng.annotations.*;

public class LandingPageTest extends LandingPage{
	
	
	@Test(priority=1)
	public void addressLine1(){
		addressText(q.getProperty("address.line1"));
	}

	@Test(priority=2)
	public void addressLine2(){
		addressText(q.getProperty("address.line2"));
	}
	@Test(priority=3)
	public void addressLine3(){
		addressText(q.getProperty("address.line3"));
	}
	@Test(priority=4)
	public void login(){
		loginPage();
		Assert.assertEquals(pageTitle(), q.getProperty("title.login"));
	}
	@Test(priority=5)
	public void register(){
		registerPage();
		Assert.assertEquals(pageTitle(), q.getProperty("title.register"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=6)
	public void homeHeader(){
		headersSelection(q.getProperty("header.one"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.home"));
		browserBack(q.getProperty("setup.URL"));

	}
	@Test(priority=7)
	public void approachHeader(){
		headersSelection(q.getProperty("header.two"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.home"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=8)
	public void sampleLessonsHeader(){
		headersSelection(q.getProperty("header.three"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.samplelessons"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=9)
	public void leaderBoardsHeader(){
		headersSelection(q.getProperty("header.four"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.home"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=10)
	public void testMonialsHeader(){
		headersSelection(q.getProperty("header.five"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.home"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=11)
	public void contactHeader(){
		headersSelection(q.getProperty("header.six"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.contact"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=12)
	public void competitionsHeader(){
		headersSelection(q.getProperty("header.seven"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.competitions"));
		browserBack(q.getProperty("setup.URL"));
	}
	
	@Test(priority=13)
	public void competitionsFooter(){
		footersSelection(q.getProperty("footer.eight"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.competitions"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=14)
	public void privacyPolicyFooter(){
		footersSelection(q.getProperty("footer.nine"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.privacypolicy"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=14)
	public void approachFooter(){
		footersSelection(q.getProperty("footer.one"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.home"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=15)
	public void aboutUSFooter(){
		footersSelection(q.getProperty("footer.two"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.aboutus"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=16)
	public void blogFooter(){
		footersSelection(q.getProperty("footer.three"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.blog"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=17)
	public void pricingPlanFooter(){
		footersSelection(q.getProperty("footer.four"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.pricing"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=18)
	public void contactUsFooter(){
		footersSelection(q.getProperty("footer.five"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.contact"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=19)
	public void sampleLessonsFooter(){
		footersSelection(q.getProperty("footer.six"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.samplelessons"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=20)
	public void leaderBoardFooter(){
		footersSelection(q.getProperty("footer.seven"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.home"));
		browserBack(q.getProperty("setup.URL"));
	}
	
	
}