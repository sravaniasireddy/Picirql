package beehyv.picirql;

import org.testng.annotations.*;
import junit.framework.Assert;

public class ParentHomePageTest extends ParentHomePage{
	@BeforeClass
	public void studentLogin(){
		loginCase("1","quanted@quanted.in","test");
	}
	
	@Test
	public void notificationsTab(){
		navBarSelection("Notifications");
		Assert.assertEquals("Notifications", selectedTab());
	}
	@Test
	public void studentsTab(){
		navBarSelection("Students");
		Assert.assertEquals("Students", selectedTab());
	}
	@Test
	public void parentForumTab(){
		navBarSelection("Parent Forum");
		Assert.assertEquals("Parent Forum", selectedTab());
	}
	@Test
	public void updateProfileTab(){
		navBarSelection("Update Profile");
		Assert.assertEquals("Update Profile", selectedTab());
	}
	@Test
	public void createTestTab(){
		navBarSelection("Create Test");
		Assert.assertEquals("Create Test", selectedTab());
	}
	@Test
	public void addingChild(){
		addChildPage();
		waitUntilAddChildPage();
		Assert.assertEquals("Add new student", newChildFormHeader());
		home();
	}
	//@Test
	public void ChildrenDetailsPage(){
		ChildrenDeatils();
	}
}
