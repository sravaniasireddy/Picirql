package beehyv.picirql;

import org.testng.annotations.*;

import junit.framework.Assert;

public class StudentHomePageTest extends StudentHomePage{
	@BeforeClass
	public void studentLogin(){
		loginCase("0","sravani.asireddy@beehyv.com","test");
	}
	
	@Test
	public void inviteFriendValidEmail(){
		inviteFriend("");
		Assert.assertEquals(q.getProperty("invitefriend.errormessage"), confirmationInviteFriend());
	}
	//@Test
	public void dashBoardTab(){
		navBarSelection("Dashboard");
		Assert.assertEquals("Dashboard", selectedTab());
	}
	//@Test
	public void lessonsTab(){
		navBarSelection("Lessons");
		Assert.assertEquals("Lessons", selectedTab());
	}
	//@Test
	public void revosionquestionsTab(){
		navBarSelection("Revision Questions");
		Assert.assertEquals("Revision Questions", selectedTab());
	}
	//@Test
	public void competitionTab(){
		navBarSelection("Competition");
	}
	//@Test
	public void rewardSlection(){
		navBarSelection("Rewards");
		Assert.assertEquals("Rewards", selectedTab());

	}
	//@Test
	public void friensTab(){
		navBarSelection("Friends");
		Assert.assertEquals("Friends", selectedPage());
		Assert.assertEquals("Friends", selectedTab());

	}
	//@Test
	public void notifictaionsPage(){
		profileOptionSelection("Notifications");
		Assert.assertEquals("Notifications", selectedPage());
	}
	//@Test
	public void messagesPage(){
		profileOptionSelection("Messages");
		Assert.assertEquals("Messages", selectedPage());
	}
	//@Test
	public void friendsPage(){
		profileOptionSelection("Friends");
	}
	//@Test
	public void challengesPage(){
		profileOptionSelection("Challenges");
		Assert.assertEquals("Challenges", selectedPage());
	}
	//@Test
	public void askAQuestionPage(){
		profileOptionSelection("Ask a Question");
		Assert.assertEquals("Ask a Question:", faqHeader());
		home();
	}
	//@Test
	public void evaluationsPage(){
		profileOptionSelection("Evaluations");
		home();
	}
	//@Test
	public void friendsSearch(){
		searchFriend("aditi");
		friendsList("aditi");
	}
}
