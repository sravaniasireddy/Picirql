package beehyv.picirql;

import org.testng.Assert;
import org.testng.annotations.*;

import utils.CommonMethods;

public class ContactPageTest extends ContactPage{
	
	
	
	@Test(priority=1)
	public void logoVerification(){
		//Assert.assertEquals(appLogo(), true);
		headersSelection(q.getProperty("header.six"));
		Assert.assertEquals(pageTitle(), q.getProperty("title.contact"));
	}
	
	@Test(priority=2)
	public void invalidcase1(){
		sendingMail("","","");
		Assert.assertEquals(formResponse(), q.getProperty("contactform.confirmation1"));
		browserRefresh();
	}
	@Test(priority=3)
	public void invalidcase2(){
		sendingMail(q.getProperty("contactform.name"),"","");
		Assert.assertEquals(formResponse(), q.getProperty("contactform.confirmation2"));
		browserRefresh();
	}
	@Test(priority=4)
	public void invalidcase3(){
		sendingMail("",q.getProperty("contactform.email"),"");
		Assert.assertEquals(formResponse(), q.getProperty("contactform.confirmation3"));
		browserRefresh();
	}
	@Test(priority=5)
	public void invalidcase4(){
		sendingMail("","",q.getProperty("contactform.message"));
		Assert.assertEquals(formResponse(), q.getProperty("contactform.confirmation4"));
		browserRefresh();
	}
	@Test(priority=6)
	public void invalidcase5(){
		sendingMail("",q.getProperty("contactform.email"),q.getProperty("contactform.message"));
		Assert.assertEquals(formResponse(), q.getProperty("contactform.confirmation5"));
		browserRefresh();
	}
	@Test(priority=7)
	public void invalidcase6(){
		sendingMail(q.getProperty("contactform.name"),"",q.getProperty("contactform.message"));
		Assert.assertEquals(formResponse(), q.getProperty("contactform.confirmation6"));
		browserRefresh();
	}
	@Test(priority=8)
	public void invalidcase7(){
		sendingMail(q.getProperty("contactform.name"),q.getProperty("contactform.email"),"");
		Assert.assertEquals(formResponse(), q.getProperty("contactform.confirmation7"));
		browserRefresh();
	}
	
	
	
}
