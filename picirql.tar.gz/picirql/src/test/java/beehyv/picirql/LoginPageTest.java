package beehyv.picirql;

import org.testng.Assert;
import org.testng.annotations.*;


public class LoginPageTest extends LoginPage{
	
	
	@Test(priority=1)
	public void logoVerification(){
	//	Assert.assertEquals(appLogo(), true);
		loginPage();
		Assert.assertEquals(formHeader(), q.getProperty("loginform.header"));
	}
	
	@Test(priority=2)
	public void invalidcase1(){
		loginCase("","","");
		Assert.assertEquals(errorMessage(), true);
		browserRefresh();
	}
	@Test(priority=3)
	public void invalidcase2(){
		loginCase(q.getProperty("loginform.usertype1"),"","");
		Assert.assertEquals(errorMessage(), true);
		browserRefresh();
	}
	@Test(priority=4)
	public void invalidcase3(){
		loginCase("",q.getProperty("loginform.useremail"),"");
		Assert.assertEquals(errorMessage(), true);
		browserRefresh();
	}
	@Test(priority=5)
	public void invalidcase4(){
		loginCase("","",q.getProperty("loginform.userpassword"));
		Assert.assertEquals(errorMessage(), true);
		browserRefresh();
	}
	@Test(priority=6)
	public void invalidcase5(){
		loginCase("",q.getProperty("loginform.userpassword"),q.getProperty("loginform.userpassword"));
		Assert.assertEquals(errorMessage(), true);
		browserRefresh();
	}
	@Test(priority=7)
	public void registerPageFromLoginPage(){
		registerLink();
		Assert.assertEquals(formHeader(), q.getProperty("registerform.header1"));
		browserBack(q.getProperty("setup.URL"));
	}
	@Test(priority=8)
	public void forgotPasswordPageFromLoginPage(){
		forgotPasswordLink();
		Assert.assertEquals(formHeader(), q.getProperty("forgotpswdform.header"));
		browserBack(q.getProperty("setup.URL"));
	}
}
